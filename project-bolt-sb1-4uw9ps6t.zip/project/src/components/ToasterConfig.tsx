import { Toaster } from 'react-hot-toast';

export function ToasterConfig() {
  return (
    <Toaster
      position="top-center"
      gutter={8}
      containerStyle={{
        top: 40,
        left: 40,
        right: 40
      }}
      toastOptions={{
        duration: 3000,
        style: {
          background: '#363636',
          color: '#fff',
          padding: '16px',
          borderRadius: '8px',
          fontSize: '14px',
          maxWidth: '400px',
          textAlign: 'center'
        },
        success: {
          iconTheme: {
            primary: '#10B981',
            secondary: '#fff',
          }
        },
        error: {
          iconTheme: {
            primary: '#EF4444',
            secondary: '#fff',
          },
          duration: 4000
        }
      }}
    />
  );
}