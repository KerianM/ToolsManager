import { LogIn, LogOut } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { UserMenu } from './UserMenu';

export function AuthButton() {
  const { isAuthenticated, logout } = useAuth();

  return (
    <div className="flex items-center gap-2">
      {isAuthenticated ? (
        <>
          <UserMenu />
          <button
            onClick={logout}
            className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-gray-900 transition-colors"
            title="退出登录"
          >
            <LogOut className="h-5 w-5" />
          </button>
        </>
      ) : (
        <button
          onClick={() => {
            // 找到并点击主页的登录按钮
            const loginButton = document.querySelector('.login-prompt-button') as HTMLButtonElement;
            if (loginButton) {
              loginButton.click();
            }
          }}
          className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:text-gray-900 transition-colors"
          title="登录"
        >
          <LogIn className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}