export interface SystemInfo {
  title: string;
  website_title: string;
  logo_url: string;
  background_url: string;
  announcement: string;
}

export interface UpdateSystemInfoData {
  title: string;
  website_title: string;
  logo_url: string;
  background_url: string;
  announcement: string;
}