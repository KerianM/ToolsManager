export interface Category {
  id: number;
  name: string;
  is_hidden: number;
  card_count?: number;
}

export interface CreateCategoryData {
  name: string;
  is_hidden: number;
}

export interface UpdateCategoryData {
  name: string;
  is_hidden: number;
}